
#ifndef WMMAC_DEFS_H
#define WMMAC_DEFS_H

typedef PACK_START enum
{
    TSPEC_DIR_UPLINK = 0,
    TSPEC_DIR_DOWNLINK = 1,
    /* 2 is a reserved value */
    TSPEC_DIR_BIDIRECT = 3,

} PACK_END IEEEtypes_WMM_TSPEC_TS_Info_Direction_e;

typedef PACK_START enum
{
    TSPEC_PSB_LEGACY = 0,
    TSPEC_PSB_TRIG = 1,

} PACK_END IEEEtypes_WMM_TSPEC_TS_Info_PSB_e;

typedef PACK_START enum
{
    /* 0 is reserved */
    TSPEC_ACCESS_EDCA = 1,
    TSPEC_ACCESS_HCCA = 2,
    TSPEC_ACCESS_HEMM = 3,

} PACK_END IEEEtypes_WMM_TSPEC_TS_Info_AccessPolicy_e;

typedef PACK_START enum
{
    TSPEC_ACKPOLICY_NORMAL = 0,
    TSPEC_ACKPOLICY_NOACK = 1,
    /* 2 is reserved */
    TSPEC_ACKPOLICY_BLOCKACK = 3,

} PACK_END IEEEtypes_WMM_TSPEC_TS_Info_AckPolicy_e;

typedef PACK_START enum
{
    TSPEC_TRAFFIC_APERIODIC = 0,
    TSPEC_TRAFFIC_PERIODIC = 1,

} PACK_END IEEEtypes_WMM_TSPEC_TS_TRAFFIC_TYPE_e;

 // ! 0: aperiodic, 1: periodic

typedef PACK_START struct
{
    IEEEtypes_WMM_TSPEC_TS_TRAFFIC_TYPE_e TrafficType:1;
    UINT8 TID:4;                // ! Unique identifier
    IEEEtypes_WMM_TSPEC_TS_Info_Direction_e Direction:2;
#if 0
    IEEEtypes_WMM_TSPEC_TS_Info_AccessPolicy_e AccessPolicy:2;  // ! 
#else
    UINT8 AccessPolicy1:1;      // ! 
    UINT8 AccessPolicy2:1;      // ! 
#endif
    UINT8 Aggregation:1;        // ! Reserved
    IEEEtypes_WMM_TSPEC_TS_Info_PSB_e PowerSaveBehavior:1;      // !
                                                                // Legacy/Trigg
    UINT8 UserPriority:3;       // ! 802.1d User Priority
    IEEEtypes_WMM_TSPEC_TS_Info_AckPolicy_e AckPolicy:2;
    UINT8 Schedule:1;
    UINT8 Reserved17_23:7;      // ! Reserved

} PACK_END IEEEtypes_WMM_TSPEC_TS_Info_t;

typedef PACK_START struct
{
    UINT16 Size:15;             // ! Nominal size in octets
    UINT16 Fixed:1;             // ! 1: Fixed size given in Size, 0: Var, size
                                // is nominal

} PACK_END IEEEtypes_WMM_TSPEC_NomMSDUSize_t;

typedef PACK_START struct
{
    UINT16 Fractional:13;       // ! Fractional portion
    UINT16 Whole:3;             // ! Whole portion

} PACK_END IEEEtypes_WMM_TSPEC_SBWA;

typedef PACK_START struct
{
    IEEEtypes_WMM_TSPEC_TS_Info_t TSInfo;
    IEEEtypes_WMM_TSPEC_NomMSDUSize_t NomMSDUSize;
    UINT16 MaximumMSDUSize;
    UINT32 MinServiceInterval;
    UINT32 MaxServiceInterval;
    UINT32 InactivityInterval;
    UINT32 SuspensionInterval;
    UINT32 ServiceStartTime;
    UINT32 MinimumDataRate;
    UINT32 MeanDataRate;
    UINT32 PeakDataRate;
    UINT32 MaxBurstSize;
    UINT32 DelayBound;
    UINT32 MinPHYRate;
    IEEEtypes_WMM_TSPEC_SBWA SurplusBWAllowance;
    UINT16 MediumTime;
} PACK_END IEEEtypes_WMM_TSPEC_Body_t;

typedef PACK_START struct
{
    UINT8 ElementId;
    UINT8 Len;
    UINT8 OuiType[4];           /* 00:50:f2:02 */
    UINT8 OuiSubType;           /* 01 */
    UINT8 Version;

    IEEEtypes_WMM_TSPEC_Body_t TspecBody;

} PACK_END IEEEtypes_WMM_TSPEC_t;

#endif
