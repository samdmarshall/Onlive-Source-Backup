
#ifndef WMMAC_DRV_H
#define WMMAC_DRV_H

/** Size of a TSPEC.  Used to allocate necessary buffer space in commands */
#define WMM_TSPEC_SIZE              63

/** Extra IE bytes allocated in messages for appended IEs after a TSPEC */
#define WMM_ADDTS_EXTRA_IE_BYTES    256

/**
 *  @brief Enumeration for the command result from an ADDTS or DELTS command 
 */
typedef enum
{
    TSPEC_RESULT_SUCCESS = 0,
    TSPEC_RESULT_EXEC_FAILURE = 1,
    TSPEC_RESULT_TIMEOUT = 2,
    TSPEC_RESULT_DATA_INVALID = 3,

} PACK_END wlan_wmm_tspec_result_e;

/**
 *  @brief IOCTL structure to send an ADDTS request and retrieve the response.
 *
 *  IOCTL structure from the application layer relayed to firmware to 
 *    instigate an ADDTS management frame with an appropriate TSPEC IE as well
 *    as any additional IEs appended in the ADDTS Action frame.
 *
 *  @sa wlan_wmm_addts_req_ioctl
 */
typedef struct
{
    wlan_wmm_tspec_result_e commandResult;

    UINT32 timeout_ms;
    UINT8 ieeeStatusCode;

    UINT32 ieDataLen;
    UINT8 ieData[WMM_TSPEC_SIZE + WMM_ADDTS_EXTRA_IE_BYTES];

} wlan_ioctl_wmm_addts_req_t;

/**
 *  @brief IOCTL structure to send a DELTS request.
 *
 *  IOCTL structure from the application layer relayed to firmware to 
 *    instigate an DELTS management frame with an appropriate TSPEC IE.
 *
 *  @sa wlan_wmm_delts_req_ioctl
 */
typedef struct
{
    wlan_wmm_tspec_result_e commandResult;

    UINT8 ieeeReasonCode;

    UINT32 ieDataLen;
    UINT8 ieData[WMM_TSPEC_SIZE];

} wlan_ioctl_wmm_delts_req_t;

typedef struct
{
    UINT8 tid;
    UINT8 valid;
    UINT8 accessCategory;
    UINT8 userPriority;

    UINT8 psb;
    UINT8 flowDir;
    UINT16 mediumTime;

} PACK_END wlan_ioctl_wmm_ts_status_t;

#endif
