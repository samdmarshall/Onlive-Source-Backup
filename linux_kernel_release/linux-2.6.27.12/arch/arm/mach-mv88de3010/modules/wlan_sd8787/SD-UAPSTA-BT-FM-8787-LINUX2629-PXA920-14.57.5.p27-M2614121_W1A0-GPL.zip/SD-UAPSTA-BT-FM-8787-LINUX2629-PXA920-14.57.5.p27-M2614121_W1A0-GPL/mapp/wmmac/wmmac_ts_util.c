/** 
 *  @file  wmmac_ts_util.c
 *
 *  @brief Utility program to generate conf files for tspec provisioning
 *     
 *  (c) Copyright � 2003-2006, Marvell International Ltd.  
 *
 */

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <asm/types.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <linux/if_ether.h>
#include <linux/if_packet.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <net/ethernet.h>
#include <netinet/in.h>
#include <linux/wireless.h>

#define MRV_EV_POINT_OFF (((char *) &(((struct iw_point *) NULL)->length)) - \
                          (char *) NULL)
#define WLAN_STATUS_SUCCESS 0
#define WLAN_STATUS_FAILURE -1
#define IW_MAX_PRIV_DEF         128
#define NELEMENTS(x) (sizeof(x)/sizeof(x[0]))

#define FLUSHIN(c) while (((c = getc(stdin)) != EOF) && (c != '\n'))

#define PACK_START
#define PACK_END __attribute__((packed))

typedef unsigned char UINT8;
typedef unsigned short UINT16;
typedef unsigned long UINT32;

static int sockfd;
static char dev_name[IFNAMSIZ + 1] = "mlan0";
static struct iw_priv_args priv_args[IW_MAX_PRIV_DEF];

static void
hexdump(UINT8 * s, int len)
{
    int i;

    for (i = 0; i < len; i++) {
        if (i != len - 1) {
            printf("%02x ", *s++);
        } else {
            printf("%02x\n", *s);
        }
        if ((i + 1) % 16 == 0) {
            printf("\n");
        }
    }
}

/** 
 *  @brief Get private info.
 *   
 *  @param ifname   A pointer to net name
 *  @return         WLAN_STATUS_SUCCESS--success, otherwise --fail
 */
static int
get_private_info(const char *ifname)
{
    /* This function sends the SIOCGIWPRIV command which is handled by the
       kernel. and gets the total number of private ioctl's available in the
       host driver. */
    struct iwreq iwr;
    int s, ret = WLAN_STATUS_SUCCESS;
    struct iw_priv_args *pPriv = priv_args;

    s = socket(PF_INET, SOCK_DGRAM, 0);
    if (s < 0) {
        perror("socket[PF_INET,SOCK_DGRAM]");
        return WLAN_STATUS_FAILURE;
    }

    memset(&iwr, 0, sizeof(iwr));
    strncpy(iwr.ifr_name, ifname, IFNAMSIZ);
    iwr.u.data.pointer = (caddr_t) pPriv;
    iwr.u.data.length = IW_MAX_PRIV_DEF;
    iwr.u.data.flags = 0;

    if (ioctl(s, SIOCGIWPRIV, &iwr) < 0) {
        perror("ioctl[SIOCGIWPRIV]");
        ret = WLAN_STATUS_FAILURE;
    } else {
        /* Return the number of private ioctls */
        ret = iwr.u.data.length;
    }

    close(s);

    return ret;
}

/** 
 *  @brief Get Sub command ioctl number
 *   
 *  @param i        command index
 *  @param priv_cnt     Total number of private ioctls availabe in driver
 *  @param ioctl_val    A pointer to return ioctl number
 *  @param subioctl_val A pointer to return sub-ioctl number
 *  @return             WLAN_STATUS_SUCCESS or WLAN_STATUS_FAILURE
 */
static int
marvell_get_subioctl_no(int i, int priv_cnt, int *ioctl_val, int *subioctl_val)
{
    int j;

    if (priv_args[i].cmd >= SIOCDEVPRIVATE) {
        *ioctl_val = priv_args[i].cmd;
        *subioctl_val = 0;
        return WLAN_STATUS_SUCCESS;
    }

    j = -1;

    /* Find the matching *real* ioctl */

    while ((++j < priv_cnt)
           && ((priv_args[j].name[0] != '\0') ||
               (priv_args[j].set_args != priv_args[i].set_args) ||
               (priv_args[j].get_args != priv_args[i].get_args))) {
    }

    /* If not found... */
    if (j == priv_cnt) {
        printf("%s: Invalid private ioctl definition for: 0x%x\n",
               dev_name, priv_args[i].cmd);
        return WLAN_STATUS_FAILURE;
    }

    /* Save ioctl numbers */
    *ioctl_val = priv_args[j].cmd;
    *subioctl_val = priv_args[i].cmd;

    return WLAN_STATUS_SUCCESS;
}

/** 
 *  @brief Get ioctl number
 *   
 *  @param ifname       A pointer to net name
 *  @param priv_cmd     A pointer to priv command buffer
 *  @param ioctl_val    A pointer to return ioctl number
 *  @param subioctl_val A pointer to return sub-ioctl number
 *  @return             WLAN_STATUS_SUCCESS or WLAN_STATUS_FAILURE
 */
static int
marvell_get_ioctl_no(const char *ifname,
                     const char *priv_cmd, int *ioctl_val, int *subioctl_val)
{
    int i;
    int priv_cnt;

    priv_cnt = get_private_info(ifname);

    /* Are there any private ioctls? */
    if (priv_cnt <= 0 || priv_cnt > IW_MAX_PRIV_DEF) {
        /* Could skip this message ? */
        printf("%-8.8s  no private ioctls.\n", ifname);
    } else {
        for (i = 0; i < priv_cnt; i++) {
            if (priv_args[i].name[0] && !strcmp(priv_args[i].name, priv_cmd)) {
                return marvell_get_subioctl_no(i, priv_cnt,
                                               ioctl_val, subioctl_val);
            }
        }
    }

    return WLAN_STATUS_FAILURE;
}

/** 
 *  @brief Retrieve the ioctl and sub-ioctl numbers for the given ioctl string
 *   
 *  @param ioctl_name   Private IOCTL string name
 *  @param ioctl_val    A pointer to return ioctl number
 *  @param subioctl_val A pointer to return sub-ioctl number
 *
 *  @return             WLAN_STATUS_SUCCESS or WLAN_STATUS_FAILURE
 */
static int
get_priv_ioctl(char *ioctl_name, int *ioctl_val, int *subioctl_val)
{
    int retval;

    retval = marvell_get_ioctl_no(dev_name,
                                  ioctl_name, ioctl_val, subioctl_val);

#if 0
    /* Debug print discovered IOCTL values */
    printf("ioctl %s: %x, %x\n", ioctl_name, *ioctl_val, *subioctl_val);
#endif

    return retval;
}

#include "wmmac_defs.h"
#include "wmmac_drv.h"

static char *acStr[] = { "BK", "BE", "VI", "VO" };

static int
ts_status(void)
{
    int ioctl_val, subioctl_val;
    struct iwreq iwr;
    wlan_ioctl_wmm_ts_status_t ts_status;
    int tid;

    if (get_priv_ioctl("ts_status",
                       &ioctl_val, &subioctl_val) == WLAN_STATUS_FAILURE) {
        return -EOPNOTSUPP;
    }

    printf("\nTID   Valid    AC   UP   PSB   FlowDir  MediumTime\n");
    printf("---------------------------------------------------\n");

    for (tid = 0; tid <= 7; tid++) {
        memset(&ts_status, 0x00, sizeof(ts_status));
        ts_status.tid = tid;

        strncpy(iwr.ifr_name, dev_name, IFNAMSIZ);
        iwr.u.data.flags = subioctl_val;
        iwr.u.data.pointer = (caddr_t) & ts_status;
        iwr.u.data.length = (sizeof(ts_status));

        if (ioctl(sockfd, ioctl_val, &iwr) < 0) {
            perror("wlanconfig: ts_status ioctl");
            return -EFAULT;
        }

        printf(" %02d     %3s    %2s    %u     %c    ",
               ts_status.tid,
               (ts_status.valid ? "Yes" : "No"),
               (ts_status.valid ? acStr[ts_status.accessCategory] : "--"),
               ts_status.userPriority, (ts_status.psb ? 'U' : 'L'));

        if ((ts_status.flowDir & 0x03) == 0) {
            printf("%s", " ---- ");
        } else {
            printf("%2s%4s",
                   (ts_status.flowDir & 0x01 ? "Up" : ""),
                   (ts_status.flowDir & 0x02 ? "Down" : ""));
        }

        printf("%12u\n", ts_status.mediumTime);
    }

    printf("\n");

    return WLAN_STATUS_SUCCESS;
}

static int
addts(IEEEtypes_WMM_TSPEC_t * pTspec)
{
    int ioctl_val, subioctl_val;
    struct iwreq iwr;
    wlan_ioctl_wmm_addts_req_t addtsReq;

    memset(&addtsReq, 0x00, sizeof(addtsReq));

    if (get_priv_ioctl("addts",
                       &ioctl_val, &subioctl_val) == WLAN_STATUS_FAILURE) {
        return -EOPNOTSUPP;
    }

    memcpy(addtsReq.ieData, (UINT8 *) pTspec, sizeof(addtsReq.ieData));
    addtsReq.timeout_ms = 2000;
    addtsReq.ieDataLen = sizeof(IEEEtypes_WMM_TSPEC_t);

    printf("TSPEC -> IOCTL\n");
    hexdump(addtsReq.ieData, sizeof(addtsReq.ieData));

    strncpy(iwr.ifr_name, dev_name, IFNAMSIZ);

    iwr.u.data.flags = subioctl_val;
    iwr.u.data.pointer = (caddr_t) & addtsReq;
    iwr.u.data.length = (sizeof(addtsReq)
                         - sizeof(addtsReq.ieData)
                         + addtsReq.ieDataLen);

    if (ioctl(sockfd, ioctl_val, &iwr) < 0) {
        perror("addts ioctl");
        return -EFAULT;
    }

    printf("IOCTL Output:\n");
    printf("ADDTS Command Result = %d\n", addtsReq.commandResult);
    printf("ADDTS IEEE Status    = %d\n", addtsReq.ieeeStatusCode);
    hexdump(addtsReq.ieData, addtsReq.ieDataLen);

    return WLAN_STATUS_SUCCESS;
}

static int
delts(IEEEtypes_WMM_TSPEC_t * pTspec)
{
    int ioctl_val, subioctl_val;
    struct iwreq iwr;
    wlan_ioctl_wmm_delts_req_t deltsReq;

    memset(&deltsReq, 0x00, sizeof(deltsReq));

    if (get_priv_ioctl("delts",
                       &ioctl_val, &subioctl_val) == WLAN_STATUS_FAILURE) {
        return -EOPNOTSUPP;
    }

    memcpy(deltsReq.ieData, (UINT8 *) pTspec, sizeof(deltsReq.ieData));
    deltsReq.ieDataLen = sizeof(deltsReq.ieData);

    strncpy(iwr.ifr_name, dev_name, IFNAMSIZ);
    iwr.u.data.flags = subioctl_val;
    iwr.u.data.pointer = (caddr_t) & deltsReq;
    iwr.u.data.length = sizeof(deltsReq);

    if (ioctl(sockfd, ioctl_val, &iwr) < 0) {
        perror("delts ioctl");
        return -EFAULT;
    }

    printf("DELTS Command Result = %d\n", deltsReq.commandResult);

    return WLAN_STATUS_SUCCESS;
}

typedef struct
{
    char sel;
    IEEEtypes_WMM_TSPEC_t *pTspec;
    char *desc;

} TspecSel_t;

#include "wmmac_tspecs.inl"

static const TspecSel_t tspecSel[] = {
    {'a', &T0B_nPS_2k, "T0B_nPS_2k"},
    {'b', &T0B_PS_8_nM, "T0B_PS_8_nM"},
    {'c', &T0D_PS_8_nM, "T0D_PS_8_nM"},
    {'d', &T2B_nPS_166k, "T2B_nPS_166k"},
    {'e', &T2B_PS_8_nM, "T2B_PS_8_nM"},
    {'f', &T2D_PS_8_nM, "T2D_PS_8_nM"},
    {'g', &T3B_nPS_360k, "T3B_nPS_360k"},
    {'h', &T4B_nPS_360k, "T4B_nPS_360k"},
    {'i', &T4U_nPS_150k, "T4U_nPS_150k"},
    {'j', &T5B_nPS_360k, "T5B_nPS_360k"},
    {'k', &T5B_nPS_720k, "T5B_nPS_720k"},
    {'l', &T5B_PS_8_nM, "T5B_PS_8_nM"},
    {'m', &T5Bopt_nPS_360k, "T5Bopt_nPS_360k"},
    {'n', &T5D_nPS_150k, "T5D_nPS_150k"},
    {'o', &T5U_nPS_100k, "T5U_nPS_100k"},
    {'p', &T5U_nPS_10M, "T5U_nPS_10M"},
    {'q', &T5U_nPS_150k, "T5U_nPS_150k"},
    {'r', &T5U_nPS_18M, "T5U_nPS_18M"},
    {'s', &T5U_nPS_2pt8M, "T5U_nPS_2.8M"},
    {'t', &T5U_nPS_300k, "T5U_nPS_300k"},
    {'u', &T5U_nPS_360k, "T5U_nPS_360k"},
    {'v', &T5U_nPS_720k, "T5U_nPS_720k"},
    {'w', &T6B_nPS_83k, "T6B_nPS_83k"},
    {'x', &T6B_PS_8_nM, "T6B_PS_8_nM"},
    {'y', &T6Bopt_nPS_83k, "T6Bopt_nPS_83k"},
    {'z', &T6D_nPS_53percent, "T6D_nPS_53percent"},
    {'0', &T6D_nPS_83k, "T6D_nPS_83k"},
    {'1', &T6U_nPS_100k, "T6U_nPS_100k"},
    {'2', &T6U_nPS_53percent, "T6U_nPS_53percent"},
    {'3', &T6U_nPS_83k, "T6U_nPS_83k"},
    {'4', &T7B_nPS_166k, "T7B_nPS_166k"},
    {'5', &T7B_nPS_360k, "T7B_nPS_360k"},
    {'6', &T7D_nPS_166k, "T7D_nPS_166k"},
    {'7', &T7U_nPS_166k, "T7U_nPS_166k"}
};

static void
dump_tspec(const TspecSel_t * pTspecSel)
{
    char dir;
    char checkStr[50];
    IEEEtypes_WMM_TSPEC_t *pTspec = pTspecSel->pTspec;

    switch (pTspec->TspecBody.TSInfo.Direction) {
    case TSPEC_DIR_UPLINK:
        dir = 'U';
        break;

    case TSPEC_DIR_DOWNLINK:
        dir = 'D';
        break;

    case TSPEC_DIR_BIDIRECT:
        dir = 'B';
        break;

    default:
        dir = '?';
        break;
    }

    sprintf(checkStr,
            "T%d%c_%s",
            pTspec->TspecBody.TSInfo.UserPriority,
            dir, pTspec->TspecBody.TSInfo.PowerSaveBehavior ? "PS" : "nPS");

    if (strncmp(checkStr, pTspecSel->desc, strlen(checkStr)) != 0) {
        sprintf(checkStr + strlen(checkStr),
                "_%lu%c",
                (pTspec->TspecBody.MinimumDataRate / 1000
                 ? pTspec->TspecBody.MinimumDataRate / 1000 : 8),
                (pTspec->TspecBody.MinimumDataRate / 1000 ? 'k' : ' '));

        printf("*%-18s: %-17s", pTspecSel->desc, checkStr);
    } else {
        sprintf(checkStr + strlen(checkStr),
                "_%lu%c",
                (pTspec->TspecBody.MinimumDataRate / 1000
                 ? pTspec->TspecBody.MinimumDataRate / 1000 : 8),
                (pTspec->TspecBody.MinimumDataRate / 1000 ? 'k' : ' '));

        printf(" %-18s: %-17s", pTspecSel->desc, checkStr);
    }

    printf("%10u     ", (unsigned int) pTspec->TspecBody.MinPHYRate);

    printf("%d.%03d",
           pTspec->TspecBody.SurplusBWAllowance.Whole,
           (pTspec->TspecBody.SurplusBWAllowance.Fractional * 1000 / 0x2000));

    printf("\n");
}

static void
dump_table(void)
{
    int x;

    for (x = 0; x < NELEMENTS(tspecSel); x++) {
        dump_tspec(tspecSel + x);
    }
}

int
main(int argc, char *argv[])
{
    int x;
    int input;
    char ch, cflush;
    IEEEtypes_WMM_TSPEC_t *pTspec = NULL;
    int do_add;
    char *pDesc = NULL;

    /* 
     * create a socket 
     */
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        fprintf(stderr, "Cannot open socket.\n");
        exit(1);
    }

    /**************************************************************/
    printf("\n[a]dd, [d]elete, [v]alidate> ");
    ch = getc(stdin);
    FLUSHIN(cflush);
    printf("\n");

    if (ch == 'a') {
        do_add = 1;
    } else if (ch == 'd') {
        do_add = 0;
    } else if (ch == 'v') {
        dump_table();
        exit(0);
    } else {
        ts_status();
        exit(0);
    }

    printf("\n---------------------------------------------\n"
           "                   TSPECS\n"
           "---------------------------------------------\n");
    for (x = 0; x < NELEMENTS(tspecSel) / 2; x++) {
        printf("%c: %-20s", tspecSel[x].sel, tspecSel[x].desc);
        printf("   %c: %s\n",
               tspecSel[x + NELEMENTS(tspecSel) / 2].sel,
               tspecSel[x + NELEMENTS(tspecSel) / 2].desc);
    }

    /**************************************************************/
    printf("\nTSPEC#> ");

    ch = getc(stdin);
    FLUSHIN(cflush);
    printf("\n");

    for (x = 0; x < NELEMENTS(tspecSel); x++) {
        if (tspecSel[x].sel == ch) {
            pTspec = tspecSel[x].pTspec;
            pDesc = tspecSel[x].desc;
        }
    }

    if ((pTspec == NULL) || (pDesc == NULL)) {
        printf("Invalid choice\n");
        exit(0);
    }

    /**************************************************************/
    printf("\nTID[%d]> ", pTspec->TspecBody.TSInfo.TID);

    ch = getc(stdin);
    FLUSHIN(cflush);
    printf("\n");

    if (isdigit(ch)) {
        input = atoi(&ch);
        if ((input <= 7) && (input >= 0)) {
            pTspec->TspecBody.TSInfo.TID = input;
        }
    }

    /**************************************************************/
    printf("\nUP[%d]> ", pTspec->TspecBody.TSInfo.UserPriority);

    ch = getc(stdin);
    FLUSHIN(cflush);
    printf("\n");

    if (isdigit(ch)) {
        input = atoi(&ch);
        if ((input <= 7) && (input >= 0)) {
            pTspec->TspecBody.TSInfo.UserPriority = input;
        }
    }

    if (do_add) {
        /**************************************************************/
        printf("\nPSB[%c](u/l)> ",
               (pTspec->TspecBody.TSInfo.PowerSaveBehavior ? 'u' : 'l'));

        ch = getc(stdin);
        input = atoi(&ch);
        FLUSHIN(cflush);
        printf("\n");

        if (ch == 'u') {
            pTspec->TspecBody.TSInfo.PowerSaveBehavior = 1;
        }

        if (ch == 'l') {
            pTspec->TspecBody.TSInfo.PowerSaveBehavior = 0;
        }
    }

    if (do_add) {
        printf("------------------------------------------\n"
               "+++ Adding TSPEC: %s\n"
               "------------------------------------------\n", pDesc);

        printf("TID          = %d\n", pTspec->TspecBody.TSInfo.TID);
        printf("UserPriority = %d\n", pTspec->TspecBody.TSInfo.UserPriority);
        printf("Direction    = 0x%02x\n", pTspec->TspecBody.TSInfo.Direction);
        printf("PSB          = %s [%d]\n",
               pTspec->TspecBody.TSInfo.PowerSaveBehavior ? "U-APSD" : "Legacy",
               pTspec->TspecBody.TSInfo.PowerSaveBehavior);
        addts(pTspec);
    } else {
        printf("----------------------\n"
               "+++ Deleting TSPEC +++\n" "----------------------\n");
        printf("TID          = %d\n", pTspec->TspecBody.TSInfo.TID);
        printf("UserPriority = %d\n", pTspec->TspecBody.TSInfo.UserPriority);
        delts(pTspec);
    }

    ts_status();

    printf("\n");

    exit(0);
}
